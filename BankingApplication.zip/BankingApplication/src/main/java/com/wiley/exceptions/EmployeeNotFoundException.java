package com.wiley.exceptions;

public class EmployeeNotFoundException extends Exception {

	public EmployeeNotFoundException(String msg)
	{
		super(msg);
	}
}
