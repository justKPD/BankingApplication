package com.wiley.exceptions;

public class AdminNotFoundException extends Exception {
	
	public AdminNotFoundException(String msg)
	{
		super(msg);
	}

}
